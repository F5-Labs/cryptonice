# cryptonice
# __init__.py

# Version of cryptonice package
__version__ = "1.4.0"
