# cryptonice
# __init__.py

# Version of cryptonice package
__version__ = "0.1.16"
